<?php
/**
 * Главная страница файлообменника
 */

// Определение доступа
define('SITE_ACCESS', true);

// Подключение конфигурации и функций
require_once 'includes/config.php';
require_once 'includes/functions.php';

// Проверка результатов загрузки из сессии
$uploadResult = null;
if (isset($_SESSION['upload_result'])) {
    $uploadResult = $_SESSION['upload_result'];
    unset($_SESSION['upload_result']);
}

// Построение содержимого страницы
$content = '
<div class="text-center mb-8">
    <h1 class="text-3xl font-medium text-white dark:text-white">' . SITE_NAME . '</h1>
    <p class="text-gray-400 dark:text-gray-400 mt-2">простой и безопасный обмен файлами</p>
</div>

<div class="apple-card p-8">
    <form id="uploadForm" method="post" action="upload.php" enctype="multipart/form-data" class="text-center">
        <div id="dropArea" class="border-2 border-dashed border-gray-600 dark:border-gray-600 rounded-lg p-8 mb-6 hover:border-apple-blue transition-colors cursor-pointer">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12 text-gray-400 dark:text-gray-400 mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
            </svg>
            <label for="fileInput" class="cursor-pointer">
                <span class="block text-white dark:text-white font-medium mb-1">перетащите файл сюда или нажмите для выбора</span>
                <span class="text-sm text-gray-400 dark:text-gray-400">максимальный размер: 50 мб</span>
                <input type="file" id="fileInput" name="file" class="hidden" required>
            </label>
        </div>
        
        <div id="fileInfo" class="mb-6 hidden">
            <div class="flex items-center justify-between mb-2">
                <span id="fileName" class="text-white dark:text-white truncate"></span>
                <span id="fileSize" class="text-sm text-gray-400 dark:text-gray-400"></span>
            </div>
            <div class="h-1 bg-gray-600 dark:bg-gray-600 rounded">
                <div id="progressBar" class="progress-bar"></div>
            </div>
        </div>
        
        <button type="submit" id="uploadButton" class="apple-button py-3 px-6 w-full font-medium" disabled>
            загрузить файл
        </button>
    </form>
    
    <!-- Сообщение об успешной загрузке с ссылкой -->
    <div id="successMessage" class="' . ($uploadResult && $uploadResult['success'] ? '' : 'hidden') . ' mt-6 text-center">
        <div class="bg-green-900 dark:bg-green-900 rounded-lg p-4 mb-4">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-green-400 dark:text-green-400 mx-auto mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
            </svg>
            <p class="text-green-400 dark:text-green-400">файл успешно загружен!</p>
        </div>
        
        <p class="text-gray-300 dark:text-gray-300 mb-3">поделитесь этой ссылкой:</p>
        <div class="flex">
            <input id="shareLink" type="text" class="apple-input py-2 px-4 w-full mr-2 text-white dark:text-white" value="' . ($uploadResult && $uploadResult['success'] ? $uploadResult['link'] : '') . '" readonly>
            <button id="copyButton" class="apple-button py-2 px-4" onclick="copyToClipboard()">копировать</button>
        </div>
    </div>
    
    <!-- Сообщение об ошибке -->
    <div id="errorMessage" class="' . ($uploadResult && !$uploadResult['success'] && $uploadResult['message'] ? '' : 'hidden') . ' mt-6 bg-red-900 dark:bg-red-900 text-red-400 dark:text-red-400 p-4 rounded-lg text-center">
        ' . ($uploadResult && !$uploadResult['success'] ? e($uploadResult['message']) : 'ошибка') . '
    </div>
</div>

<div class="mt-8 text-center text-sm text-gray-500 dark:text-gray-500">
    <p>файлы хранятся временно и могут быть удалены после периода неактивности</p>
</div>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        const dropArea = document.getElementById("dropArea");
        const fileInput = document.getElementById("fileInput");
        const fileName = document.getElementById("fileName");
        const fileSize = document.getElementById("fileSize");
        const fileInfo = document.getElementById("fileInfo");
        const uploadButton = document.getElementById("uploadButton");
        const uploadForm = document.getElementById("uploadForm");
        const progressBar = document.getElementById("progressBar");
        const successMessage = document.getElementById("successMessage");
        const errorMessage = document.getElementById("errorMessage");
        const shareLink = document.getElementById("shareLink");
        
        // Обработка выбора файла
        fileInput.addEventListener("change", handleFileSelect);
        
        // Обработка перетаскивания файлов
        ["dragenter", "dragover", "dragleave", "drop"].forEach(eventName => {
            dropArea.addEventListener(eventName, preventDefaults, false);
        });
        
        ["dragenter", "dragover"].forEach(eventName => {
            dropArea.addEventListener(eventName, highlight, false);
        });
        
        ["dragleave", "drop"].forEach(eventName => {
            dropArea.addEventListener(eventName, unhighlight, false);
        });
        
        dropArea.addEventListener("drop", handleDrop, false);
        
        // Обработка отправки формы
        uploadForm.addEventListener("submit", handleUpload);
        
        function preventDefaults(e) {
            e.preventDefault();
            e.stopPropagation();
        }
        
        function highlight() {
            dropArea.classList.add("border-apple-blue");
            dropArea.classList.add("bg-[#0a84ff1a]");
        }
        
        function unhighlight() {
            dropArea.classList.remove("border-apple-blue");
            dropArea.classList.remove("bg-[#0a84ff1a]");
        }
        
        function handleDrop(e) {
            const dt = e.dataTransfer;
            const files = dt.files;
            fileInput.files = files;
            handleFileSelect();
        }
        
        function handleFileSelect() {
            if (fileInput.files.length > 0) {
                const file = fileInput.files[0];
                
                // Проверка размера файла
                if (file.size > ' . MAX_FILE_SIZE . ') {
                    showError("файл слишком большой. максимальный размер: ' . (MAX_FILE_SIZE / 1024 / 1024) . ' мб");
                    fileInput.value = "";
                    return;
                }
                
                // Отображение информации о файле
                fileName.textContent = file.name;
                fileSize.textContent = formatBytes(file.size);
                fileInfo.classList.remove("hidden");
                uploadButton.disabled = false;
            } else {
                fileInfo.classList.add("hidden");
                uploadButton.disabled = true;
            }
        }
        
        function formatBytes(bytes) {
            if (bytes === 0) return "0 байт";
            const k = 1024;
            const sizes = ["байт", "кб", "мб", "гб"];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
        }
        
        function handleUpload(e) {
            e.preventDefault();
            
            // Отображение прогресс-бара
            progressBar.style.width = "0%";
            
            const formData = new FormData(uploadForm);
            const xhr = new XMLHttpRequest();
            
            xhr.upload.addEventListener("progress", function(e) {
                if (e.lengthComputable) {
                    const percentComplete = (e.loaded / e.total) * 100;
                    progressBar.style.width = percentComplete + "%";
                }
            });
            
            xhr.addEventListener("load", function() {
                if (xhr.status === 200) {
                    try {
                        const response = JSON.parse(xhr.responseText);
                        
                        if (response.success) {
                            // Отображение сообщения об успехе и ссылки
                            successMessage.classList.remove("hidden");
                            shareLink.value = response.link;
                            
                            // Скрытие формы
                            dropArea.classList.add("hidden");
                            uploadButton.classList.add("hidden");
                            
                            // Скрытие сообщения об ошибке, если оно было видимо
                            errorMessage.classList.add("hidden");
                        } else {
                            showError(response.message);
                        }
                    } catch (e) {
                        showError("ошибка обработки ответа сервера");
                    }
                } else {
                    showError("ошибка загрузки файла: " + xhr.status);
                }
            });
            
            xhr.addEventListener("error", function() {
                showError("сетевая ошибка при загрузке");
            });
            
            xhr.open("POST", "upload.php", true);
            xhr.setRequestHeader("X-Requested-With", "XMLHttpRequest");
            xhr.send(formData);
        }
        
        function showError(message) {
            errorMessage.textContent = message;
            errorMessage.classList.remove("hidden");
            successMessage.classList.add("hidden");
        }
    });
    
    function copyToClipboard() {
        const shareLink = document.getElementById("shareLink");
        const copyButton = document.getElementById("copyButton");
        
        shareLink.select();
        document.execCommand("copy");
        
        copyButton.textContent = "скопировано!";
        setTimeout(function() {
            copyButton.textContent = "копировать";
        }, 2000);
    }
</script>';

// Отображение страницы
displayTemplate('загрузка файла', $content); 