<?php
/**
 * Подвал сайта
 * 
 * Содержит копирайт и дополнительную навигацию
 */

// Предотвращение прямого доступа к файлу
if (!defined('SITE_ACCESS')) {
    exit('Прямой доступ к файлу запрещен!');
}
?>

<footer class="mt-12 pt-6 border-t border-gray-700 dark:border-gray-700">
    <div class="flex flex-col sm:flex-row items-center justify-between">
        <!-- Копирайт -->
        <div class="mb-4 sm:mb-0">
            <p class="text-sm text-gray-500 dark:text-gray-500"><?= SITE_NAME ?> &copy; <?= date('Y') ?></p>
        </div>
        
        <!-- Дополнительная навигация -->
        <nav>
            <ul class="flex space-x-4">
                <li>
                    <a href="index.php" class="text-xs text-gray-500 dark:text-gray-500 hover:text-gray-300 dark:hover:text-gray-300">
                        главная
                    </a>
                </li>
                <li>
                    <a href="info.php" class="text-xs text-gray-500 dark:text-gray-500 hover:text-gray-300 dark:hover:text-gray-300">
                        информация
                    </a>
                </li>
                <li>
                    <a href="contact.php" class="text-xs text-gray-500 dark:text-gray-500 hover:text-gray-300 dark:hover:text-gray-300">
                        контакты
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</footer> 