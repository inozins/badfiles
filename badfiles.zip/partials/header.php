<?php
/**
 * Шапка сайта
 * 
 * Содержит логотип и навигационное меню
 */

// Предотвращение прямого доступа к файлу
if (!defined('SITE_ACCESS')) {
    exit('Прямой доступ к файлу запрещен!');
}

// Получение текущего пути для подсветки активного пункта меню
$currentPage = basename($_SERVER['PHP_SELF']);
?>

<header class="mb-8">
    <div class="flex flex-col sm:flex-row items-center justify-between py-4 border-b border-gray-700 dark:border-gray-700">
        <!-- Логотип -->
        <div class="flex items-center mb-4 sm:mb-0">
            <a href="index.php" class="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-apple-blue dark:text-apple-blue mr-2" viewBox="0 0 20 20" fill="currentColor">
                    <path fill-rule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clip-rule="evenodd" />
                </svg>
                <span class="text-xl font-medium text-white dark:text-white"><?= SITE_NAME ?></span>
            </a>
        </div>
        
        <!-- Навигация -->
        <nav>
            <ul class="flex space-x-6">
                <li>
                    <a href="index.php" class="text-sm <?= $currentPage === 'index.php' ? 'text-apple-blue dark:text-apple-blue' : 'text-gray-400 dark:text-gray-400 hover:text-white dark:hover:text-white' ?>">
                        главная
                    </a>
                </li>
                <li>
                    <a href="info.php" class="text-sm <?= $currentPage === 'info.php' ? 'text-apple-blue dark:text-apple-blue' : 'text-gray-400 dark:text-gray-400 hover:text-white dark:hover:text-white' ?>">
                        информация
                    </a>
                </li>
                <li>
                    <a href="contact.php" class="text-sm <?= $currentPage === 'contact.php' ? 'text-apple-blue dark:text-apple-blue' : 'text-gray-400 dark:text-gray-400 hover:text-white dark:hover:text-white' ?>">
                        контакты
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</header> 