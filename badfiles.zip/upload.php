<?php
/**
 * Обработка загрузки файла
 */

// Определение доступа
define('SITE_ACCESS', true);

// Подключение конфигурации и функций
require_once 'includes/config.php';
require_once 'includes/functions.php';

// Проверка метода запроса
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

// Инициализация результата
$result = [
    'success' => false,
    'message' => '',
    'link' => ''
];

// Проверка наличия файла для загрузки
if (!isset($_FILES['file'])) {
    $result['message'] = 'файл не выбран';
} else {
    $file = $_FILES['file'];
    
    // Проверка размера файла
    if ($file['size'] > MAX_FILE_SIZE) {
        $result['message'] = 'файл слишком большой. максимальный размер: ' . (MAX_FILE_SIZE / 1024 / 1024) . ' мб';
    } 
    // Проверка ошибок загрузки
    else if ($file['error'] !== UPLOAD_ERR_OK) {
        $result['message'] = 'ошибка загрузки (код: ' . $file['error'] . ')';
    } 
    else {
        // Генерация уникального идентификатора
        $fileId = generateUniqueId();
        
        // Получение расширения файла
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        
        // Перемещение загруженного файла в хранилище
        $storagePath = UPLOAD_DIR . $fileId;
        if (move_uploaded_file($file['tmp_name'], $storagePath)) {
            
            // Сохранение метаданных файла
            $fileInfo = [
                'original_name' => $file['name'],
                'mime_type' => $file['type'],
                'size' => $file['size'],
                'uploaded_at' => time(),
                'extension' => $extension
            ];
            
            // Сохранение информации о файле
            file_put_contents(UPLOAD_DIR . $fileId . '.info', json_encode($fileInfo));
            
            // Установка успешного результата
            $result['success'] = true;
            $result['message'] = 'файл успешно загружен!';
            
            // Формирование ссылки на файл
            $protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? 'https' : 'http';
            $result['link'] = $protocol . '://' . $_SERVER['HTTP_HOST'] . '/' . $fileId;
        } else {
            $result['message'] = 'не удалось сохранить файл';
        }
    }
}

// Возвращаем JSON-ответ для AJAX-запросов
if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
    header('Content-Type: application/json');
    echo json_encode($result);
    exit;
} else {
    // Для обычных запросов - устанавливаем в сессию и перенаправляем на главную
    $_SESSION['upload_result'] = $result;
    header('Location: index.php');
    exit;
} 