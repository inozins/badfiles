<?php
/**
 * Страница с контактами и формой обратной связи
 */

// Определение доступа
define('SITE_ACCESS', true);

// Подключение конфигурации и функций
require_once 'includes/config.php';
require_once 'includes/functions.php';

// Содержимое страницы
$content = '
<div class="text-center mb-8">
    <h1 class="text-3xl font-medium text-white dark:text-white">контакты</h1>
    <p class="text-gray-400 dark:text-gray-400 mt-2">свяжитесь с нами или оставьте сообщение</p>
</div>

<div class="grid grid-cols-1 md:grid-cols-2 gap-8">
    <div>
        <div class="apple-card p-6">
            <h2 class="text-xl font-medium text-white dark:text-white mb-4">контактная информация</h2>
            <div class="text-gray-300 dark:text-gray-300 space-y-4">
                <div class="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-apple-blue dark:text-apple-blue mt-0.5 mr-3" viewBox="0 0 20 20" fill="currentColor">
                        <path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z" />
                        <path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z" />
                    </svg>
                    <div>
                        <p class="text-sm text-gray-400 dark:text-gray-400">email:</p>
                        <p>contact@' . $_SERVER['HTTP_HOST'] . '</p>
                    </div>
                </div>
                
                <div class="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-apple-blue dark:text-apple-blue mt-0.5 mr-3" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM4.332 8.027a6.012 6.012 0 011.912-2.706C6.512 5.73 6.974 6 7.5 6A1.5 1.5 0 019 7.5V8a2 2 0 004 0 2 2 0 011.523-1.943A5.977 5.977 0 0116 10c0 .34-.028.675-.083 1H15a2 2 0 00-2 2v2.197A5.973 5.973 0 0110 16v-2a2 2 0 00-2-2 2 2 0 01-2-2 2 2 0 00-1.668-1.973z" clip-rule="evenodd" />
                    </svg>
                    <div>
                        <p class="text-sm text-gray-400 dark:text-gray-400">расположение:</p>
                        <p>российская федерация</p>
                    </div>
                </div>
                
                <div class="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-apple-blue dark:text-apple-blue mt-0.5 mr-3" viewBox="0 0 20 20" fill="currentColor">
                        <path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z" />
                    </svg>
                    <div>
                        <p class="text-sm text-gray-400 dark:text-gray-400">режим работы:</p>
                        <p>сервис работает 24/7</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div>
        <div class="apple-card p-6">
            <h2 class="text-xl font-medium text-white dark:text-white mb-4">обратная связь</h2>
            <form class="space-y-4">
                <div>
                    <label for="name" class="block text-sm text-gray-400 dark:text-gray-400 mb-1">ваше имя</label>
                    <input type="text" id="name" name="name" class="apple-input w-full px-3 py-2 text-white dark:text-white" placeholder="введите имя">
                </div>
                
                <div>
                    <label for="email" class="block text-sm text-gray-400 dark:text-gray-400 mb-1">ваш email</label>
                    <input type="email" id="email" name="email" class="apple-input w-full px-3 py-2 text-white dark:text-white" placeholder="введите email">
                </div>
                
                <div>
                    <label for="message" class="block text-sm text-gray-400 dark:text-gray-400 mb-1">сообщение</label>
                    <textarea id="message" name="message" rows="4" class="apple-input w-full px-3 py-2 text-white dark:text-white" placeholder="введите сообщение"></textarea>
                </div>
                
                <button type="button" class="apple-button py-2 px-4 w-full font-medium">
                    отправить сообщение
                </button>
                
                <p class="text-xs text-gray-500 dark:text-gray-500 mt-2">
                    * это демо-форма без функционала отправки
                </p>
            </form>
        </div>
    </div>
</div>';

// Отображение страницы
displayTemplate('контакты', $content); 