<?php
/**
 * Скачивание и предпросмотр файла
 */

// Определение доступа
define('SITE_ACCESS', true);

// Подключение конфигурации и функций
require_once 'includes/config.php';
require_once 'includes/functions.php';

// Проверка наличия идентификатора файла
if (!isset($_GET['id']) || empty($_GET['id'])) {
    // Перенаправление на страницу с ошибкой 404
    header('Location: 404.php');
    exit;
}

// Получение идентификатора файла
$fileId = $_GET['id'];

// Проверка формата ID файла
if (!preg_match('/^[a-z]{' . LINK_LENGTH . '}$/', $fileId)) {
    // Перенаправление на страницу с ошибкой 404
    header('Location: 404.php');
    exit;
}

// Определение путей к файлу
$filePath = UPLOAD_DIR . $fileId;
$fileInfoPath = UPLOAD_DIR . $fileId . '.info';

// Проверка существования файла
if (!file_exists($filePath) || !file_exists($fileInfoPath)) {
    // Перенаправление на страницу с ошибкой 404
    header('Location: 404.php');
    exit;
}

// Чтение информации о файле
$fileInfo = json_decode(file_get_contents($fileInfoPath), true);

// Если не удалось прочитать информацию о файле или информация повреждена
if ($fileInfo === null || !isset($fileInfo['original_name']) || !isset($fileInfo['mime_type'])) {
    $fileInfo = [
        'original_name' => 'файл',
        'mime_type' => 'application/octet-stream',
        'size' => filesize($filePath)
    ];
}

// Проверка физического наличия файла и его размера
if (!is_readable($filePath) || filesize($filePath) === 0) {
    // Перенаправление на страницу с ошибкой 404
    header('Location: 404.php');
    exit;
}

// Определение типа контента для предпросмотра
$contentType = $fileInfo['mime_type'];
$isImage = strpos($contentType, 'image/') === 0;
$isVideo = strpos($contentType, 'video/') === 0;
$isAudio = strpos($contentType, 'audio/') === 0;
$canPreview = $isImage || $isVideo || $isAudio;

// Форматирование размера файла
$formattedSize = formatFileSize($fileInfo['size']);

// Если запрошено прямое скачивание
if (isset($_GET['download'])) {
    // Устанавливаем заголовки для скачивания файла
    header('Content-Description: File Transfer');
    header('Content-Type: ' . $fileInfo['mime_type']);
    header('Content-Disposition: attachment; filename="' . $fileInfo['original_name'] . '"');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($filePath));
    
    // Отправка файла клиенту
    readfile($filePath);
    exit;
}

// Если файл можно предварительно просмотреть
$previewUrl = $canPreview ? '/' . UPLOAD_DIR . $fileId : '';

// Подготовка контента для страницы просмотра файла
$content = '
<div class="text-center mb-8">
    <h1 class="text-3xl font-medium text-white dark:text-white">файл</h1>
    <p class="text-gray-400 dark:text-gray-400 mt-2">информация и скачивание</p>
</div>

<div class="apple-card p-6">
    <div class="mb-6 space-y-3">
        <div class="flex items-center justify-between">
            <h2 class="text-xl font-medium text-white dark:text-white break-all">' . e($fileInfo['original_name']) . '</h2>
            <a href="?id=' . $fileId . '&download=1" class="apple-button py-2 px-4 text-sm font-medium flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-1" viewBox="0 0 20 20" fill="currentColor">
                    <path fill-rule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clip-rule="evenodd" />
                </svg>
                скачать файл
            </a>
        </div>
        
        <div class="grid grid-cols-2 gap-4 text-sm">
            <div>
                <p class="text-gray-400 dark:text-gray-400">тип файла:</p>
                <p class="text-white dark:text-white">' . e($fileInfo['mime_type']) . '</p>
            </div>
            <div>
                <p class="text-gray-400 dark:text-gray-400">размер:</p>
                <p class="text-white dark:text-white">' . e($formattedSize) . '</p>
            </div>
        </div>
    </div>
    
    ' . ($canPreview ? '<hr class="border-gray-700 dark:border-gray-700 my-6">' : '') . '
    
    ' . ($canPreview ? '<div class="preview-container">' : '') . '
    
    ' . ($isImage ? '
        <div class="flex justify-center">
            <img src="' . $previewUrl . '" alt="' . e($fileInfo['original_name']) . '" class="max-w-full rounded-lg">
        </div>
    ' : '') . '
    
    ' . ($isVideo ? '
        <div class="flex justify-center">
            <video controls class="max-w-full rounded-lg">
                <source src="' . $previewUrl . '" type="' . e($fileInfo['mime_type']) . '">
                ваш браузер не поддерживает этот видеоформат
            </video>
        </div>
    ' : '') . '
    
    ' . ($isAudio ? '
        <div class="flex justify-center">
            <audio controls class="w-full">
                <source src="' . $previewUrl . '" type="' . e($fileInfo['mime_type']) . '">
                ваш браузер не поддерживает этот аудиоформат
            </audio>
        </div>
    ' : '') . '
    
    ' . ($canPreview ? '</div>' : '') . '
</div>

' . (!$canPreview ? '
<div class="mt-6 text-center">
    <p class="text-gray-400 dark:text-gray-400 mb-4">для этого типа файлов предпросмотр недоступен</p>
    <a href="?id=' . $fileId . '&download=1" class="apple-button py-3 px-6 text-white font-medium inline-flex items-center">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
            <path fill-rule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clip-rule="evenodd" />
        </svg>
        скачать файл
    </a>
</div>
' : '') . '

<script>
    document.addEventListener("DOMContentLoaded", function() {
        // Дополнительный JavaScript для страницы, если потребуется
    });
</script>';

// Отображение страницы
displayTemplate('просмотр файла', $content); 