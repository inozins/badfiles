<?php
/**
 * Основной шаблон
 * 
 * Шаблон для всех страниц сайта
 */

// Предотвращение прямого доступа к файлу
if (!defined('SITE_ACCESS')) {
    exit('Прямой доступ к файлу запрещен!');
}
?>
<!DOCTYPE html>
<html lang="ru" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($title) ?> - <?= SITE_NAME ?></title>
    
    <!-- Tailwind CSS через CDN с настройкой темного режима -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <script>
        // Настройка Tailwind CSS
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['-apple-system', 'BlinkMacSystemFont', 'San Francisco', 'Helvetica Neue', 'Helvetica', 'Arial', 'sans-serif'],
                    },
                    colors: {
                        'apple-dark': '#1c1c1e',
                        'apple-darker': '#2c2c2e',
                        'apple-blue': '#0a84ff',
                        'apple-gray': '#8e8e93',
                    },
                    boxShadow: {
                        'apple': '0 0 10px rgba(0, 0, 0, 0.5)',
                    },
                }
            }
        }
    </script>
    
    <style>
        /* Дополнительные стили для темного интерфейса в стиле Apple */
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'San Francisco', 'Helvetica Neue', Helvetica, Arial, sans-serif;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            background-color: #000000;
            color: #f5f5f7;
        }
        
        .apple-button {
            background-color: #0a84ff;
            border-radius: 8px;
            color: white;
            transition: all 0.2s ease;
        }
        
        .apple-button:hover {
            background-color: #0071e3;
        }
        
        .apple-input {
            border-radius: 8px;
            border: 1px solid #3a3a3c;
            background-color: #1c1c1e;
        }
        
        .apple-card {
            background-color: #1c1c1e;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
            transition: all 0.2s ease;
        }
        
        .apple-card:hover {
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        }
        
        .progress-bar {
            width: 0%;
            height: 4px;
            background-color: #0a84ff;
            border-radius: 2px;
            transition: width 0.3s ease;
        }
    </style>
</head>
<body class="bg-black dark:bg-black min-h-screen">
    <div class="container mx-auto px-4 py-8 max-w-2xl">
        <?php include 'partials/header.php'; ?>
        
        <?= $content ?>
        
        <?php include 'partials/footer.php'; ?>
    </div>
</body>
</html> 